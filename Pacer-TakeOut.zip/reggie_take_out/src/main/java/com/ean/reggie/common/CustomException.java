package com.ean.reggie.common;

/**
 * @description:TODO
 * @author:Povlean
 */
public class CustomException extends RuntimeException{
    public CustomException(String mess){
        super(mess);
    }
}
