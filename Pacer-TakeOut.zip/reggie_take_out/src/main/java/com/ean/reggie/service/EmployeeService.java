package com.ean.reggie.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.ean.reggie.entity.Employee;
import org.springframework.stereotype.Service;

public interface EmployeeService extends IService<Employee> {
}
