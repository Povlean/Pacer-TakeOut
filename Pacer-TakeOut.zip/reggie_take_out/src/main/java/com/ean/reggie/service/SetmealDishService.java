package com.ean.reggie.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.ean.reggie.entity.SetmealDish;
import com.ean.reggie.mapper.SetmealDishMapper;

public interface SetmealDishService extends IService<SetmealDish> {
}
